# Laborator: funcții, metode și importuri pe web
# Student: Pascar Marius
BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde
# Exercițiu 21:
print("Exercitiul 21:")
import requests
def fetch(url):
    response = requests.get(url, timeout=TIMEOUT)
    return response
raspuns = fetch(BASE_URL)
print("Codul de stare:", raspuns.status_code)
# Exercițiu 22:
print("Exercitiul 22:")
import requests
import time
def get_status(url):
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code
status1=get_status(BASE_URL + "/")
print("Codul de stare:", status1)
time.sleep(1)
status2=get_status(BASE_URL + "/robots.txt")
print("Codul de stare:", status2)
time.sleep(1)
status3=get_status(BASE_URL + "/sitemap.xml")
print("Codul de stare:", status3)
# Exercițiu 23:
print("Exercitiul 23:")
import requests
def fetch(url, timeout=10):
    response = requests.get(url, timeout=timeout)
    return response
raspuns = fetch(BASE_URL)
print("Codul de stare:", raspuns.status_code)
raspuns = fetch(BASE_URL, timeout=3)
print("Codul de stare:", raspuns.status_code)
# Exercițiu 24:
print("Exercitiul 24:")
import requests
def get_title(html):
    start = html.find("<title>") + len("<title>")
    end = html.find("</title>")
    return html[start:end].strip()
raspuns = requests.get(BASE_URL)
html = raspuns.text
title = get_title(html)
print("Titlul paginii:", title)
# Exercițiu 25:
print("Exercitiul 25:")
import requests
def get_title(html):
    ''' Returnează titlul paginii web din conținutul HTML.'''
    start = html.find("<title>") + len("<title>")
    end = html.find("</title>")
    return html[start:end].strip()
help(get_title)
# Exercițiu 26:
print("Exercitiul 26:")
import requests
def get_status(url: str) -> int:
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code
try:
    status = get_status(123)
    print("Codul de stare:", status)
except requests.RequestException:
    print("Eroare: URL invalid.")
# Adnotarile de tip nu opresc executarea programului.
# Ele doar indica tipurile de date asteptate.
# Eroarea apare deoarece requests.get() primeste un numar in loc de un URL.
# Exercițiu 27:
print("Exercitiul 27:")
import requests
def page_exists(url):
    try:
        response = requests.get(url, timeout=TIMEOUT)
        return response.ok
    except requests.RequestException:
        return False
raspuns = page_exists(BASE_URL)
print("Pagina exista:", raspuns)
raspuns = page_exists("https://this-domain-does-not-exist.invalid")
print("Pagina exista:", raspuns)
# Exercițiu 28:
print("Exercitiul 28:")
import requests
def check_paths(base,paths):
    rezultat = {}
    for path in paths:
        response = requests.get(base + path, timeout=TIMEOUT)
        rezultat[path] = response.status_code
    return rezultat
raspuns = check_paths(BASE_URL, ["/", "/robots.txt", "/sitemap.xml"])
print("Calea:", raspuns)
# Exercițiu 29:
print("Exercitiul 29:")
import requests
def get_header(url, name, default="lipseste"):
    response = requests.get(url, timeout=TIMEOUT)
    return response.headers.get(name, default)
raspuns = get_header(BASE_URL,name="Server")
print("Server:", raspuns)
# Exercițiu 30:
print("Exercitiul 30:")
import requests
def security_headers(url):
    response = requests.get(url, timeout=TIMEOUT)
    antete = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]
    rezultat = {}
    for antet in antete:
        rezultat[antet] = antet in response.headers
    return rezultat
raspuns = security_headers(BASE_URL)
print(raspuns)
# Exercitiul 31:
print("Exercitiul 31:")
import requests
def score_headers(results):
    numar = 0
    for valoare in results.values():
        if valoare == True:
            numar += 1

    return str(numar) + "/" + str(len(results))
raspuns = score_headers(security_headers(BASE_URL))
print("Scorul antetelor:", raspuns)
import requests
# Exercitiul 32:
print("Exercitiul 32:")
import requests
def fetch_robots(base):
    response = requests.get(base + "/robots.txt", timeout=TIMEOUT)
    if response.status_code == 404:
        return None
    return response.text
def disallowed_paths(robots_text):
    rezultat = []
    if robots_text == None:
        return rezultat
    for linie in robots_text.splitlines():
        if linie.strip().lower().startswith("disallow:"):
            cale = linie.split(":", 1)[1].strip()
            rezultat.append(cale)
    return rezultat
text = fetch_robots(BASE_URL)
print("Continut robots.txt:")
print(text)
raspuns = disallowed_paths(text)
print("Rezultat:", raspuns)
# Exercitiul 33:
print("Exercitiul 33:")
import requests
def response_times(*urls):
    rezultat = {}
    for url in urls:
        response = requests.get(url, timeout=TIMEOUT)
        rezultat[url] = response.elapsed.total_seconds()
    return rezultat
raspuns = response_times(BASE_URL, ECHO_URL)
print(raspuns)
# Exercitiul 34:
print("Exercitiul 34:")
def log(message, **details):
    rezultat = message
    for cheie, valoare in details.items():
        rezultat += " | " + cheie + "=" + str(valoare)
    print(rezultat)
log("verificat", url=BASE_URL, status=200)
# print() afiseaza valoarea pe ecran, dar nu o returneaza.
# return transmite valoarea din functie, pentru a putea fi folosita mai departe in program.