# Laborator: functii, metode si importuri pe web
# Student: Pascar Marius
BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde
# Exercitiul 35:
print("Exercitiul 35:")
from urllib.parse import urlparse
def descompune_url(url):
    rezultat = urlparse(url)
    print("Scheme:", rezultat.scheme)
    print("Netloc:", rezultat.netloc)
    print("Path:", rezultat.path)
    print("Query:", rezultat.query)
    print("Fragment:", rezultat.fragment)
descompune_url("https://cybercor.org/path?x=1#top")
# Exercitiul 36:
print("Exercitiul 36:")
from urllib.parse import urljoin
def compune_url(base, links):
    rezultat = []
    for link in links:
        rezultat.append(urljoin(base, link))
    return rezultat
raspuns = compune_url(BASE_URL, ["/about", "contact.html", "../index.html"])
print(raspuns)
# Exercitiul 37:
print("Exercitiul 37:")
import requests
import re
def extract_links(html):
    links = re.findall(r'href="([^"]+)"', html)
    rezultat = []
    for link in links:
        if link not in rezultat:
            rezultat.append(link)
    return rezultat
response = requests.get(BASE_URL, timeout=TIMEOUT)
links = extract_links(response.text)
print(links)
# Exercitiul 38:
print("Exercitiul 38:")
from urllib.parse import urljoin, urlparse
def split_links(links, domain):
    interne = []
    externe = []
    for link in links:
        url_complet = urljoin(BASE_URL, link)
        domeniu_link = urlparse(url_complet).netloc
        if domeniu_link == domain:
            interne.append(url_complet)
        else:
            externe.append(url_complet)
    return interne, externe
interne, externe = split_links(links, "cybercor.org")
print("Linkuri interne:", interne)
print("Linkuri externe:", externe)
# Exercitiul 39:
print("Exercitiul 39:")
from html.parser import HTMLParser
import requests
class ImageFinder(HTMLParser):
    def __init__(self):
        super().__init__()
        self.images = []
    def handle_starttag(self, tag, attrs):
        if tag == "img":
            src = dict(attrs).get("src")
            if src != None:
                self.images.append(src)
test_html = """
<html><body>
  <img src="/logo.png" alt="Logo">
  <IMG SRC="poza.jpg">
  <img alt="imagine fara src">
  <img src="https://cdn.example.com/banner.webp" />
  <a href="/despre">Aceasta nu este o imagine</a>
</body></html>
"""
finder = ImageFinder()
finder.feed(test_html)
print(finder.images)
assert finder.images == [
    "/logo.png",
    "poza.jpg",
    "https://cdn.example.com/banner.webp"
], "Parserul nu a gasit exact imaginile asteptate"
print("Testul a trecut!")
response = requests.get(BASE_URL, timeout=TIMEOUT)
finder = ImageFinder()
finder.feed(response.text)
print(len(finder.images), "imagini gasite")
for src in finder.images:
    print(src)
print("Numar taguri img:", response.text.lower().count("<img"))
# Exercitiul 40:
print("Exercitiul 40:")
import requests
import hashlib
def page_fingerprint(url):
    response = requests.get(url, timeout=TIMEOUT)
    return hashlib.sha256(response.content).hexdigest()
amprenta1 = page_fingerprint(BASE_URL)
amprenta2 = page_fingerprint(BASE_URL)
print("Prima amprenta:", amprenta1)
print("A doua amprenta:", amprenta2)
print("Sunt egale:", amprenta1 == amprenta2)
# Amprentele sunt diferite daca se modifica continutul paginii.
# Exercitiul 41:
print("Exercitiul 41:")
import requests
import json
def save_headers(url):
    response = requests.get(url, timeout=TIMEOUT)
    with open("headers.json", "w") as file:
        json.dump(dict(response.headers), file, indent=2)
    with open("headers.json", "r") as file:
        antete = json.load(file)
    return antete
raspuns = save_headers(BASE_URL)
print("Content-Type:", raspuns.get("Content-Type", "lipseste"))
# Exercitiul 42:
print("Exercitiul 42:")
import socket
def resolve(hostname):
    return socket.gethostbyname(hostname)
raspuns = resolve("cybercor.org")
print("Adresa IP:", raspuns)
# Exercitiul 43:
print("Exercitiul 43:")
import socket
import ssl
from datetime import datetime, timezone
def cert_days_left(hostname):
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as conexiune:
            certificat = conexiune.getpeercert()
            expirare = certificat["notAfter"]
    data_expirare = ssl.cert_time_to_seconds(expirare)
    data_curenta = datetime.now(timezone.utc).timestamp()
    zile = int((data_expirare - data_curenta) // 86400)
    return zile
raspuns = cert_days_left("cybercor.org")
print("Zile pana la expirarea certificatului:", raspuns)
