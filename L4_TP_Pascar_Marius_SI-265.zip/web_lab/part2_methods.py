# Laborator: funcții, metode și importuri pe web
# Student: Pascar Marius
BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde
#Exercitiu 9:
print("Exercitiul 9:")
from urllib import response

import requests
raspuns = requests.get(BASE_URL)
print("Cod de stare:", raspuns.status_code) #atribut
print("Succes:", raspuns.ok) #atribut
print("URL:", raspuns.url) #atribut
print("Encoding:", raspuns.encoding) #atribut
# Exercițiu 10:
print("Exercitiul 10:")
import requests
# Pagina principala
raspuns = requests.get(BASE_URL)
raspuns.raise_for_status()
print("Pagina principala a fost accesata cu succes.")
# Pagina care nu exista
try:
    raspuns = requests.get(BASE_URL + "/this-page-does-not-exist")
    raspuns.raise_for_status()
except requests.HTTPError:
    print("Eroare: pagina solicitata nu exista.")
# Exercițiu 11:
print("Exercitiul 11:")
import requests
raspuns = requests.get(BASE_URL)
for nume, valoare in raspuns.headers.items():
    print(nume + ":", valoare)
# Exercițiu 12:
print("Exercitiul 12:")
import requests
raspuns = requests.get(BASE_URL)
print("Server:", raspuns.headers.get("Server", "lipseste"))
print("Content-Type:", raspuns.headers.get("Content-Type", "lipseste"))
print("content-type:", raspuns.headers.get("content-type", "lipseste"))
# Observatie: "Content-Type" si "content-type" returneaza aceeasi valoare, deoarece numele antetelor HTTP nu tin cont de litere mari sau mici.
# Exercițiu 13:
print("Exercitiul 13:")
import requests
raspuns = requests.get(BASE_URL)
print("Numarul de aparitii ale cuvântului 'cyber':", raspuns.text.lower().count("cyber"))
# Putem inlantui .lower() si .count() deoarece .lower() returneaza tot un sir de caractere, iar pe acel sir putem apela imediat metoda .count().
# Exercițiu 14:
print("Exercitiul 14:")
import requests
raspuns = requests.get(BASE_URL)    
html=raspuns.text
start=html.find("<title>") + len("<title>")
end=html.find("</title>")
print("Titlul paginii:", html[start:end].strip())   
# Exercițiu 15:
print("Exercitiul 15:")
import requests
raspuns = requests.get(BASE_URL)
linii=raspuns.text.splitlines()
print("Numarul de linii din pagina:", len(linii))
print("Lungimea celei mai lungi linii:", len(max(linii, key=len)))
# Exercițiu 16:
print("Exercitiul 16:")
import requests
raspuns = requests.get(BASE_URL)
securizare=raspuns.url.startswith("https://")
if securizare==True:
    print("Conexiune securizată ")
else:
    print("Conexiune nesecurizată ")
# Exercițiu 17:
print("Exercitiul 17:")
import requests
raspuns = requests.get("http://cybercor.org")
for redirectionare in raspuns.history:
    print("Codul de stare:", redirectionare.status_code)
    print("URL-ul redirectionarii:", redirectionare.url)
print("URL-ul final:", raspuns.url)
# Exercițiu 18:
print("Exercitiul 18:")
import requests
raspuns1=requests.head(BASE_URL)
raspuns2=requests.get(BASE_URL)
print("Metoda HEAD:", raspuns1.content, "\nMarime:", len(raspuns1.content))
print("Metoda GET:", raspuns2.content, "\nMarime:", len(raspuns2.content))
# Observatie: raspuns1.content este gol deoarece metoda HEAD nu returneaza corpul raspunsului, ci doar anteturile. De aceea, lungimea continutului este 0. In schimb, raspuns2.content contine corpul raspunsului, deci lungimea continutului este mai mare de 0.
# Exercițiu 19:
print("Exercitiul 19:")
import requests
raspuns = requests.get(BASE_URL)
cookies = raspuns.cookies
for cookie in cookies:
    print("Nume cookie:", cookie.name)
    print("Securizat:", cookie.secure)
if len(cookies) == 0:
    print("Nu exista cookies.")
# Exercițiu 20:
print("Exercitiul 20:")
import requests
obiect=requests.Session()
obiect.headers.update({"User-Agent": "WebLab-Pascar_Marius"})
raspuns = obiect.get(ECHO_URL + "/headers")
print("Antetele trimise de client:", raspuns.json()["headers"])
#response.text este un atribut, de aceea nu are paranteze și returnează direct corpul răspunsului ca text.
#response.json() este o metodă, de aceea are paranteze () și trebuie apelată pentru a transforma corpul răspunsului din format JSON într-un obiect Python (dicționar sau listă).

