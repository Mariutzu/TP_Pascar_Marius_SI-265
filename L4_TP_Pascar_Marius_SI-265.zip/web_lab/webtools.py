# Laborator: functii, metode si importuri pe web
# Student: Pascar Marius
# Partea 5: webtools.py
import requests
import socket
import ssl
import re
import json
from urllib.parse import urlparse, urljoin
from datetime import datetime, timezone
TIMEOUT = 10
# Exercitiul 44:
def fetch(url):
    response = requests.get(url, timeout=TIMEOUT, headers=DEFAULT_HEADERS)
    return response
def get_status(url):
    response = fetch(url)
    return response.status_code
def get_title(html):
    start = html.find("<title>")
    end = html.find("</title>")
    if start == -1 or end == -1:
        return "Titlu lipsa"
    start = start + len("<title>")
    return html[start:end].strip()
def security_headers(url):
    response = fetch(url)
    antete = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]
    rezultat = {}
    for antet in antete:
        rezultat[antet] = antet in response.headers
    return rezultat
# Exercitiul 47:
DEFAULT_HEADERS = {"User-Agent": "WebLab-Pascar-Marius"}
# Exercitiul 49:
def check_paths(base, paths):
    rezultat = {}
    for path in paths:
        response = fetch(base.rstrip("/") + path)
        rezultat[path] = response.status_code
    return rezultat
# Exercitiul 50:
def score_headers(results):
    numar = 0
    for valoare in results.values():
        if valoare == True:
            numar += 1
    return str(numar) + "/" + str(len(results))
def resolve(hostname):
    return socket.gethostbyname(hostname)
def cert_days_left(hostname):
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as conexiune:
            certificat = conexiune.getpeercert()
            expirare = certificat["notAfter"]
    data_expirare = ssl.cert_time_to_seconds(expirare)
    data_curenta = datetime.now(timezone.utc).timestamp()
    return int((data_expirare - data_curenta) // 86400)
def extract_links(html):
    links = re.findall(r'href="([^"]+)"', html)
    rezultat = []
    for link in links:
        if link not in rezultat:
            rezultat.append(link)
    return rezultat
def split_links(links, base):
    interne = []
    externe = []
    domain = urlparse(base).netloc
    for link in links:
        url_complet = urljoin(base, link)
        if urlparse(url_complet).netloc == domain:
            interne.append(url_complet)
        else:
            externe.append(url_complet)
    return interne, externe
def fetch_robots(base):
    response = fetch(base.rstrip("/") + "/robots.txt")
    if response.status_code == 404:
        return None
    return response.text
def disallowed_paths(robots_text):
    rezultat = []
    if robots_text == None:
        return rezultat
    for linie in robots_text.splitlines():
        if linie.strip().lower().startswith("disallow:"):
            cale = linie.split(":", 1)[1].strip()
            rezultat.append(cale)
    return rezultat
def site_report(url):
    response = fetch(url)
    hostname = urlparse(response.url).hostname
    status = response.status_code
    final_url = response.url
    titlu = get_title(response.text)
    ip = resolve(hostname)
    http_url = "http://" + urlparse(url).netloc + urlparse(url).path
    redirect_response = fetch(http_url)
    redirectionari = []
    for r in redirect_response.history:
        redirectionari.append(str(r.status_code) + " -> " + r.headers.get("Location", ""))
    scor = score_headers(security_headers(url))
    zile = cert_days_left(hostname)
    links = extract_links(response.text)
    interne, externe = split_links(links, response.url)
    robots = fetch_robots(response.url)
    cai = disallowed_paths(robots)
    raport = {
        "url": url,
        "status": status,
        "final_url": final_url,
        "title": titlu,
        "ip": ip,
        "redirects": redirectionari,
        "security_score": scor,
        "certificate_days_left": zile,
        "internal_links": len(interne),
        "external_links": len(externe),
        "disallowed_paths": cai
    }
    print("=== Raport site:", url, "===")
    print("Cod de stare:", status)
    print("URL final:", final_url)
    print("Titlu:", titlu)
    print("Adresa IP:", ip)
    print("Redirectionari:", redirectionari)
    print("Scor securitate:", scor)
    print("Certificat:", zile, "zile ramase")
    print("Legaturi:", len(interne), "interne,", len(externe), "externe")
    print("Cai interzise:", cai)
    with open("report.json", "w", encoding="utf-8") as file:
        json.dump(raport, file, indent=2, ensure_ascii=False)
    print("Salvat in report.json")
    return raport
# Exercitiul 46:
if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))
# Autotestul ruleaza doar cand executam direct webtools.py.
# Cand importam modulul in main.py, autotestul nu se executa.