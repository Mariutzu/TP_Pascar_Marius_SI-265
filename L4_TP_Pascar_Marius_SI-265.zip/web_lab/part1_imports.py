# Laborator: funcții, metode și importuri pe web
# Student: Pascar Marius
BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde
#Exercitiu 1:
print("Exercitiul 1:")
import requests
print("Versiunea:" + requests.__version__)
import urllib.request
# requests este o biblioteca externa, de aceea trebuie instalata separat cu pip.
# urllib face parte din biblioteca standard Python, de aceea nu trebuie instalata.
#Exercitiu 2:
print("Exercitiul 2:")
# Stilul 1
import requests
raspuns = requests.get(BASE_URL)
print("Cod de stare:", raspuns.status_code)
# Avantaj: se vede clar ca functia get apartine bibliotecii requests.
# Stilul 2
from requests import get
raspuns = get(BASE_URL)
print("Cod de stare:", raspuns.status_code)
# Avantaj: putem scrie direct get(), deci codul este mai scurt.
#Exercitiu 3:
print("Exercitiul 3:")
import requests as req
raspuns = req.get(BASE_URL)
# Un alias face codul mai usor de citit atunci cand scurteaza un nume lung si este usor de inteles. Il face mai greu de citit atunci cand aliasul este prea scurt sau nu arata clar ce reprezinta.
#Exercitiu 4:
print("Exercitiul 4:")
import urllib.request
cerere = urllib.request.Request(BASE_URL,headers={"User-Agent": "Mozilla/5.0"})
raspuns = urllib.request.urlopen(cerere)
print("Cod de stare:", raspuns.status)
continut = raspuns.read()
text = continut.decode("utf-8")
print("Primele 200 de caractere:" + text[:200])
#Exercitiu 5:
print("Exercitiul 5:")
import requests
print(dir(requests))
print(type(requests.get))
print(type(requests.Session))
print(type(requests.exceptions))
# get este o functie.
# Session este o clasa.
# exceptions este un modul.
#Exercitiu 6:
print("Exercitiul 6:")
import requests
help(requests.get)
raspuns = requests.get(BASE_URL, timeout=TIMEOUT)
print("Cod de stare:", raspuns.status_code)
#Exercitiul 7:
print("Exercitiul 7:")
import requests
import time
start = time.perf_counter()
response = requests.get(BASE_URL, timeout=TIMEOUT)
stop = time.perf_counter()
durata = stop - start
print("Timp masurat cu perf_counter:", durata, "secunde")
print("Timp masurat cu response.elapsed:", response.elapsed.total_seconds(), "secunde")
#Exercitiu 8:
print("Exercitiul 8:")
try:
    import bs4
except ImportError:
    print("Instalati modulul cu: pip install beautifulsoup4")