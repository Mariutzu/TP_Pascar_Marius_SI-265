# Laborator: functii, metode si importuri pe web
# Student: Pascar Marius
# Partea 5: main.py
import webtools
from webtools import get_title, security_headers, DEFAULT_HEADERS
import argparse
import csv
from datetime import datetime
# Exercitiul 48:
parser = argparse.ArgumentParser()
parser.add_argument("url")
args = parser.parse_args()
url = args.url
# Exercitiul 44:
print("Exercitiul 44:")
raspuns = webtools.get_title(webtools.fetch(url).text)
print("Titlul paginii:", raspuns)
# Exercitiul 45:
print("Exercitiul 45:")
raspuns = get_title(webtools.fetch(url).text)
print("Titlul paginii:", raspuns)
print("Antete de securitate:", security_headers(url))
# Daca definesc in main.py o functie get_title dupa import,
# aceasta va inlocui functia importata cu acelasi nume.
# Exercitiul 46:
print("Exercitiul 46:")
# Autotestul ruleaza doar la executarea directa a webtools.py.
# Cand importam webtools in main.py, autotestul nu ruleaza.
# Exercitiul 47:
print("Exercitiul 47:")
print("DEFAULT_HEADERS:", DEFAULT_HEADERS)
# Exercitiul 48:
print("Exercitiul 48:")
print("URL primit:", url)
print("Cod de stare:", webtools.get_status(url))
# Exercitiul 49:
print("Exercitiul 49:")
paths = ["/", "/robots.txt", "/sitemap.xml"]
rezultat = webtools.check_paths(url, paths)
with open("report.csv", "w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)
    writer.writerow(["path", "status", "checked_at"])
    for path, status in rezultat.items():
        writer.writerow([path, status, datetime.now().isoformat()])
print("Salvat in report.csv")
# Exercitiul 50:
print("Exercitiul 50:")
webtools.site_report(url)